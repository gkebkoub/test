<div id="menuGauche"> 
	<ul id="menuList">
		<li>
		Comptable :
		<?php echo $_SESSION['prenom']."  ".$_SESSION['nom']  ?><br><br>
		</li>
        <li class="smenu">
		<a href="index.php?uc=etatFrais&action=creer" title="Fiches Créées  ">Fiches Créées</a>
        </li>
        <li class="smenu">
        <a href="index.php?uc=etatFrais&action=cloturer" title="Fiches Cloturées">Fiches Cloturées</a>
        </li> 
        <li class="smenu">
        <a href="index.php?uc=validerFrais&action=choisirVisiteur" title="Fiches à Valider">Valider Frais</a>
        </li>
        <li class="smenu">
        <a href="index.php?uc=suivrePaiementFrais&action=choisirFichesPaiement" title="Fiches à Mettre en paiement">Suivre Paiement Frais</a>
        </li>
        <li class="smenu">
        <a href="index.php?uc=etatFrais&action=rembourser" title="Fiches Remboursées">Fiches Remboursées</a>
        </li>
        <hr style="width:104px; color:firebrick; background-color:firebrick; height:2px;" />
        <li class="smenu">
        <a href="index.php?uc=etatFrais&action=selectionnerMois" title="Fiches Archivées">Fiches Archivées</a>
        </li>
        <li class="smenu">
        <a href="index.php?uc=connexion&action=deconnexion" title="Se déconnecter">Déconnexion</a>
        </li>
    </ul>
</div>
    