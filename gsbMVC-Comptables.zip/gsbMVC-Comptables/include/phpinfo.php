<?php

phpinfo() ;
?>
